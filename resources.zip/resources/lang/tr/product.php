<?php

return [
    'size'=> 'Boyut',
    'color'=> 'Renk',
    'popular'=> 'Popüler Ürün',




];
