
<!-- Vendor JS-->
<script src="{{asset('frontend/nest/js/vendor/modernizr-3.6.0.min.js')}}"></script>
<script src="{{asset('frontend/nest/js/vendor/jquery-3.6.0.min.js')}}"></script>
<script src="{{asset('frontend/nest/js/vendor/jquery-migrate-3.3.0.min.js')}}"></script>
<script src="{{asset('frontend/nest/js/vendor/bootstrap.bundle.min.js')}}"></script>
<script src="{{asset('frontend/nest/js/plugins/slick.js')}}"></script>
<script src="{{asset('frontend/nest/js/plugins/jquery.syotimer.min.js')}}"></script>
<script src="{{asset('frontend/nest/js/plugins/waypoints.js')}}"></script>
<script src="{{asset('frontend/nest/js/plugins/wow.js')}}"></script>
<script src="{{asset('frontend/nest/js/plugins/perfect-scrollbar.js')}}"></script>
<script src="{{asset('frontend/nest/js/plugins/magnific-popup.js')}}"></script>
<script src="{{asset('frontend/nest/js/plugins/select2.min.js')}}"></script>
<script src="{{asset('frontend/nest/js/plugins/counterup.js')}}"></script>
<script src="{{asset('frontend/nest/js/plugins/jquery.countdown.min.js')}}"></script>
<script src="{{asset('frontend/nest/js/plugins/images-loaded.js')}}"></script>
<script src="{{asset('frontend/nest/js/plugins/isotope.js')}}"></script>
<script src="{{asset('frontend/nest/js/plugins/scrollup.js')}}"></script>
<script src="{{asset('frontend/nest/js/plugins/jquery.vticker-min.js')}}"></script>
<script src="{{asset('frontend/nest/js/plugins/jquery.theia.sticky.js')}}"></script>
<script src="{{asset('frontend/nest/js/plugins/jquery.elevatezoom.js')}}"></script>
<!-- Template  JS -->
<script src="{{asset('frontend/nest/js/main.js?v=5.6')}}"></script>
<script src="{{asset('frontend/nest/js/shop.js?v=5.6')}}"></script>
