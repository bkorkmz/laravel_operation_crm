<?php

return [
    'add_special_features' =>'Ek Özellikler',
    'select_an_attributes' =>'Özellik Seçiniz',
    'size'=> 'Boyut',
    'color'=> 'Renk',
    'popular'=> 'Popüler Ürün',
    'best-sales'=> 'Çok Satılan Ürün',




];
